<template>
  <!--Header-->
  <div class="row center-align hide-on-med-and-down" id="header">
    <div class="col s12">
      <img id="logo" src="../assets/images/nysl_logo.png" alt="nysl_logo" class="responsive-image" />
    </div>
  </div>
</template>

<script>
export default {
  name: "Header"
};
</script>